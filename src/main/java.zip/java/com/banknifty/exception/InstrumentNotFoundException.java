package com.banknifty.exception;

public class InstrumentNotFoundException extends MarketDataException {

    public InstrumentNotFoundException(String symbol) {

        super(
                ErrorCode.INSTRUMENT_NOT_FOUND,
                "Instrument not found : " + symbol
        );

    }

}